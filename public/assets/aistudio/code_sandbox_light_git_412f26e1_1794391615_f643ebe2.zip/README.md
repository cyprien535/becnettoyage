# Propreté Plus Bénin — Site vitrine de nettoyage professionnel

Site statique (HTML / CSS / JavaScript) pour une entreprise de nettoyage professionnel intervenant à
**Abomey-Calavi, Cotonou et Porto-Novo** (Bénin). Le site présente les prestations, rassure le visiteur et
convertit les demandes via un formulaire de devis connecté à une base de données.

---

## 1. Objectifs du projet

- Présenter clairement trois prestations : **bureaux**, **appartements**, **fin de chantier**.
- Positionner l'entreprise sur ses **trois zones d'intervention**, avec une page par ville.
- Générer des **demandes commerciales** (devis, contact) depuis n'importe quelle page.
- Apporter de la valeur informative via une section **conseils** (SEO / réassurance).
- Fournir un site **responsive**, accessible et rapide, sans dépendance à un serveur applicatif.

---

## 2. Arborescence du site (pages publiées)

| Page | Chemin |
| --- | --- |
| Accueil | `index.html` |
| Nos services (hub) | `services/index.html` |
| — Nettoyage de bureaux | `services/nettoyage-bureaux.html` |
| — Nettoyage d'appartements | `services/nettoyage-appartements.html` |
| — Nettoyage de fin de chantier | `services/nettoyage-fin-de-chantier.html` |
| À propos | `a-propos.html` |
| Zones d'intervention (hub) | `zones-intervention/index.html` |
| — Abomey-Calavi | `zones-intervention/abomey-calavi.html` |
| — Cotonou | `zones-intervention/cotonou.html` |
| — Porto-Novo | `zones-intervention/porto-novo.html` |
| Demander un devis | `devis.html` |
| Conseils et actualités (hub) | `conseils/index.html` |
| — 8 articles (voir liste ci-dessous) | `conseils/*.html` |
| FAQ | `faq.html` |
| Contact | `contact.html` |
| Mentions légales | `mentions-legales.html` |
| Politique de confidentialité | `politique-confidentialite.html` |
| Conditions de service | `conditions-service.html` |

### Articles de la section Conseils

1. `conseils/maintenir-bureau-propre-quotidien.html`
2. `conseils/frequence-nettoyage-bureaux-entreprise.html`
3. `conseils/preparer-appartement-avant-emmenagement.html`
4. `conseils/pourquoi-nettoyage-apres-travaux.html`
5. `conseils/etapes-nettoyage-fin-de-chantier.html`
6. `conseils/entretenir-sols-sans-abimer.html`
7. `conseils/choisir-entreprise-nettoyage-benin.html`
8. `conseils/criteres-prix-nettoyage-professionnel.html`

---

## 3. Fonctionnalités réalisées

### Structure & navigation
- En-tête collant avec logo, navigation complète et bouton « Demander un devis ».
- Barre supérieure affichant les horaires, le téléphone et le lien WhatsApp.
- Menu mobile (bouton hamburger) avec fermeture au clic et à la touche `Échap`.
- Fil d'Ariane sur toutes les pages internes, liens de pagination entre articles.
- Pied de page complet : présentation, services, zones, coordonnées, liens légaux.

### Contenu éditorial
- 19 pages rédigées, avec un contenu réellement différencié par ville (Calavi, Cotonou, Porto-Novo).
- Trois pages de service détaillées (présentation, prestations incluses, déroulement, FAQ dédiée).
- 8 articles de conseils avec table des matières, encadrés, tableaux et liens vers les services.
- Aucune donnée inventée : pas d'ancienneté, de certification ni de témoignage fictif
  (les témoignages sont des emplacements explicitement réservés).

### Éléments transversaux (exigés au cahier des charges)
- Bouton **WhatsApp flottant** présent sur toutes les pages, avec message pré-rempli.
- Boutons d'appel téléphonique et d'e-mail sur toutes les pages.
- Liens actifs sur le bouton WhatsApp, le téléphone et l'e-mail via `js/site-config.js`.
- Animations d'apparition au défilement, désactivées si `prefers-reduced-motion`.

### Formulaires (fonctionnels, connectés à la base de données)
- **`devis.html`** → table `demandes_devis` : nom, téléphone, e-mail, prestation, ville, quartier,
  type de local, superficie, fréquence (ponctuelle / régulière / après travaux), date souhaitée,
  préférence de contact, description.
- **`contact.html`** → table `messages_contact` : nom, téléphone, e-mail, sujet, message.
- Validation côté navigateur, message de confirmation après envoi, message d'erreur explicite en cas
  d'échec, réinitialisation du formulaire après succès.

---

## 4. Modèles de données

Deux tables sont définies dans `.tables/schema.json` et exposées via l'API REST des tables
(`tables/{table}`).

### `demandes_devis`

| Champ | Type | Description |
| --- | --- | --- |
| `id` | text | Identifiant unique (géré par la plateforme) |
| `nom_complet` | text | Nom et prénom du demandeur |
| `telephone` | text | Téléphone de contact |
| `email` | text | E-mail (facultatif) |
| `ville` | text | Abomey-Calavi / Cotonou / Porto-Novo / autre |
| `quartier` | text | Quartier de l'intervention |
| `service` | text | Prestation demandée |
| `type_local` | text | Bureau, appartement, commerce, chantier… |
| `superficie` | text | Superficie ou nombre de pièces (texte libre) |
| `frequence` | text | Ponctuelle / Régulière / Après travaux |
| `date_souhaitee` | text | Date souhaitée (YYYY-MM-DD) |
| `description` | rich_text | Description détaillée du besoin |
| `contact_prefere` | text | Téléphone / WhatsApp / E-mail |
| `statut` | text | Statut de traitement (par défaut : `nouveau`) |
| `cree_le` | datetime | Horodatage de création |

### `messages_contact`

| Champ | Type | Description |
| --- | --- | --- |
| `id` | text | Identifiant unique |
| `nom_complet` | text | Nom et prénom |
| `email` | text | E-mail |
| `telephone` | text | Téléphone (facultatif) |
| `sujet` | text | Sujet du message |
| `message` | rich_text | Contenu du message |
| `cree_le` | datetime | Horodatage de création |

### Endpoints utilisés (JavaScript côté client)

| Méthode | URI | Usage |
| --- | --- | --- |
| `POST` | `tables/demandes_devis` | Créer une demande de devis |
| `POST` | `tables/messages_contact` | Créer un message de contact |
| `GET` | `tables/demandes_devis?page=1&limit=100` | Lire les demandes (consultation) |
| `GET` | `tables/messages_contact?page=1&limit=100` | Lire les messages (consultation) |

Les formulaires sont déclenchés par l'attribut `data-table` présent sur la balise `<form>`.
Le script `js/main.js` lit cet attribut et envoie les données en JSON.

---

## 5. Organisation des fichiers

```
index.html
a-propos.html
devis.html
contact.html
faq.html
mentions-legales.html
politique-confidentialite.html
conditions-service.html
services/
  index.html
  nettoyage-bureaux.html
  nettoyage-appartements.html
  nettoyage-fin-de-chantier.html
zones-intervention/
  index.html
  abomey-calavi.html
  cotonou.html
  porto-novo.html
conseils/
  index.html
  + 8 articles.html
css/
  style.css          (design system complet, responsive, impression)
js/
  site-config.js     (coordonnées modifiables — voir ci-dessous)
  main.js            (config, navigation, animations, formulaires)
images/
  logo-bec-nettoyage.png              (logo fourni par le client — original, fond gris)
  logo-bec-nettoyage-transparent.png  (version détourée, utilisée en en-tête et pied de page)
  *.jpg                               (visuels libres de droits)
```

### Identité visuelle (logo & couleurs)

Le logo **BEC Nettoyage** fourni par le client est affiché dans l'en-tête et le pied de page de
**toutes** les pages, via la version détourée `images/logo-bec-nettoyage-transparent.png`
(l'original à fond gris est conservé dans `images/logo-bec-nettoyage.png`).
Dans le pied de page, le logo est posé sur une plaque blanche car le mot « NETTOYAGE » est très foncé.

La palette du site est directement issue des couleurs du logo, définie en variables CSS dans
`css/style.css` (bloc `:root`) :

| Variable | Valeur | Usage |
| --- | --- | --- |
| `--navy` | `#02164f` | texte fort, pied de page, bandeaux |
| `--primary` | `#0a5be8` | boutons, liens, accents (bleu BEC) |
| `--accent` | `#0090cc` | survols, aplats secondaires |
| `--cyan` | `#00d2ff` | accents lumineux, puces, filets |

Pour changer la charte graphique, il suffit de modifier ces quatre variables : tout le site suit.

### ⚠️ Personnalisation indispensable avant mise en ligne

Toutes les coordonnées se pilotent depuis **un seul fichier** : `js/site-config.js`.

```js
window.SITE_CONFIG = {
  phone: '+22997000000',        // téléphone réel (format international)
  phoneDisplay: '+229 97 00 00 00',
  whatsapp: '22997000000',      // WhatsApp sans "+" ni espace
  email: 'contact@propreteplus-benin.com',
  horaires: 'Lundi – Samedi, 7h30 – 19h00'
};
```

Ces valeurs sont automatiquement appliquées partout : barre supérieure, pied de page, bouton WhatsApp
flottant, boutons d'appel, pages Contact et Devis. **Aucune modification page par page n'est nécessaire.**

À compléter également :
- Les mentions légales, la politique de confidentialité et les conditions de service contiennent des
  champs entre crochets `[…]` (raison sociale, IFU/RCCM, hébergeur, dirigeant, délais) à renseigner.
- L'adresse postale dans `contact.html` (carte « Adresse postale »).
- Les témoignages de `index.html` sont des emplacements réservés, à remplacer par de vrais avis.

---

## 6. Fonctionnalités non encore implémentées

- **Espace d'administration des demandes** : les demandes sont stockées via l'API des tables, mais il
  n'existe pas encore d'interface de consultation interne dans le site.
- **Notifications par e-mail** lors d'une nouvelle demande : impossible en site statique sans service
  tiers ; un report par WhatsApp / téléphone reste nécessaire.
- **Témoignages clients réels** : structure prête, contenus à fournir.
- **Photos de l'équipe** : section prévue dans « À propos », à compléter avec les autorisations.
- **Carte interactive** des zones d'intervention.
- **Blog multi-pages avec pagination serveur** : la section conseils est statique.
- **Multilingue** (français uniquement pour l'instant).

---

## 7. Pistes de développement recommandées

1. **Renseigner les coordonnées réelles** dans `js/site-config.js` et compléter les pages légales.
2. **Collecter et intégrer de vrais témoignages** clients, avec accord écrit.
3. **Ajouter des photos authentiques** de l'entreprise et des chantiers (renforce la confiance).
4. **Mettre en place une consultation des demandes** : page interne protégée ou export régulier.
5. **Suivre les demandes** : utiliser le champ `statut` (`nouveau`, `en cours`, `traité`) pour piloter
   le traitement commercial.
6. **Ajouter des données structurées** `LocalBusiness` par ville pour le référencement local.
7. **Publier régulièrement de nouveaux conseils** pour développer la visibilité sur les moteurs.
8. **Mesurer les conversions** : nombre de demandes de devis par service et par ville.

---

## 8. URLs publiques

- **Site en production** : à générer depuis l'onglet **Publish** de la plateforme (ou via un déploiement
  hébergé), une fois les coordonnées personnalisées.
- **API des tables (relative au site)** :
  - `tables/demandes_devis`
  - `tables/messages_contact`

> Important : la base de données de prévisualisation (données visibles dans l'éditeur) et la base du site
> déployé sont **deux espaces distincts**. Pour que les données de l'éditeur apparaissent sur le site
> publié, il faut synchroniser la base de prévisualisation vers la base live.

---

## 9. Accessibilité et qualité

- Structure sémantique (`header`, `nav`, `main`, `section`, `article`, `aside`, `footer`).
- Lien d'évitement « Aller au contenu principal » sur chaque page.
- Attributs `alt` sur toutes les images, `aria-label` sur les contrôles.
- Navigation au clavier possible, styles de focus visibles.
- Contrastes vérifiés, animations respectant `prefers-reduced-motion`.
- Feuille de style d'impression incluse.

---

## 10. Licences des visuels

Les photographies utilisées proviennent de sources **libres de droits ou sous licence autorisant leur
usage**. Si une image doit être retirée sur réclamation motivée, elle sera remplacée sans délai.
Les visuels de l'équipe et des chantiers sont à substituer par des photos propres à l'entreprise.
