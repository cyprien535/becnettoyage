/* ==========================================================================
   Configuration centrale du site
   --------------------------------------------------------------------------
   ⚠️  À PERSONNALISER : modifiez uniquement les valeurs ci-dessous.
   Toutes les pages (en-tête, pied de page, bouton WhatsApp, formulaires
   pré-remplis) se mettent à jour automatiquement.
   ========================================================================== */
window.SITE_CONFIG = {
  company: 'Propreté Plus Bénin',
  baseline: 'Nettoyage professionnel à Abomey-Calavi, Cotonou et Porto-Novo',

  /* Téléphone professionnel : format international, sans espace ni symbole */
  phone: '+22997000000',
  phoneDisplay: '+229 97 00 00 00',

  /* WhatsApp : indicatif pays + numéro, sans "+" ni espace */
  whatsapp: '22997000000',
  whatsappMessage:
    'Bonjour Propreté Plus Bénin, je souhaite obtenir un devis pour une prestation de nettoyage.',

  /* Adresse e-mail professionnelle */
  email: 'contact@propreteplus-benin.com',

  /* Villes desservies */
  villes: ['Abomey-Calavi', 'Cotonou', 'Porto-Novo'],

  /* Horaires (à confirmer) */
  horaires: 'Lundi – Samedi, 7h30 – 19h00'
};
