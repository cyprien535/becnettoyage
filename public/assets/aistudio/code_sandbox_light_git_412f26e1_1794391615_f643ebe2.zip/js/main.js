/* ==========================================================================
   Propreté Plus Bénin — Script principal
   1. Application de la configuration (téléphone, WhatsApp, e-mail, année)
   2. Navigation mobile
   3. Ombre de l'en-tête au défilement
   4. Animations d'apparition au défilement
   5. Soumission des formulaires vers l'API de tables
   ========================================================================== */
(function () {
  'use strict';

  var cfg = window.SITE_CONFIG || {};
  var root = (document.body && document.body.getAttribute('data-root')) || '';

  function qsa(selector, scope) {
    return Array.prototype.slice.call((scope || document).querySelectorAll(selector));
  }

  /* 1. Application de la configuration ------------------------------------ */
  function applySiteConfig() {
    qsa('[data-site="phone"]').forEach(function (el) {
      el.textContent = cfg.phoneDisplay || cfg.phone || '';
      if (el.tagName === 'A' && cfg.phone) {
        el.setAttribute('href', 'tel:' + String(cfg.phone).replace(/[^\d+]/g, ''));
      }
    });

    qsa('[data-site="email"]').forEach(function (el) {
      if (cfg.email) {
        el.textContent = cfg.email;
        if (el.tagName === 'A') {
          el.setAttribute('href', 'mailto:' + cfg.email);
        }
      }
    });

    qsa('[data-site="whatsapp"]').forEach(function (el) {
      if (!cfg.whatsapp) return;
      var message = el.getAttribute('data-wa-message') || cfg.whatsappMessage || '';
      el.setAttribute(
        'href',
        'https://wa.me/' + cfg.whatsapp + (message ? '?text=' + encodeURIComponent(message) : '')
      );
      el.setAttribute('target', '_blank');
      el.setAttribute('rel', 'noopener noreferrer');
    });

    qsa('[data-site="year"]').forEach(function (el) {
      el.textContent = String(new Date().getFullYear());
    });

    qsa('[data-site="horaires"]').forEach(function (el) {
      el.textContent = cfg.horaires || '';
    });
  }

  /* 2. Navigation mobile -------------------------------------------------- */
  function initNav() {
    var toggle = document.querySelector('.nav-toggle');
    var nav = document.getElementById('primary-nav');
    if (!toggle || !nav) return;

    function closeNav() {
      nav.classList.remove('is-open');
      toggle.setAttribute('aria-expanded', 'false');
    }

    toggle.addEventListener('click', function () {
      var open = nav.classList.toggle('is-open');
      toggle.setAttribute('aria-expanded', open ? 'true' : 'false');
    });

    nav.addEventListener('click', function (event) {
      if (event.target.closest('a')) closeNav();
    });

    document.addEventListener('keydown', function (event) {
      if (event.key === 'Escape') closeNav();
    });

    window.addEventListener('resize', function () {
      if (window.innerWidth > 960) closeNav();
    });
  }

  /* 3. Ombre de l'en-tête au défilement ----------------------------------- */
  function initHeaderShadow() {
    var header = document.querySelector('.site-header');
    if (!header) return;
    function update() {
      if (window.scrollY > 8) header.classList.add('is-scrolled');
      else header.classList.remove('is-scrolled');
    }
    update();
    window.addEventListener('scroll', update, { passive: true });
  }

  /* 4. Animations d'apparition au défilement ------------------------------ */
  function initReveal() {
    var items = qsa('.reveal');
    if (!items.length) return;

    function revealAll() {
      items.forEach(function (el) { el.classList.add('is-visible'); });
    }

    var reduce = window.matchMedia('(prefers-reduced-motion: reduce)').matches;
    if (reduce || !('IntersectionObserver' in window)) {
      revealAll();
      return;
    }

    var observer = new IntersectionObserver(
      function (entries) {
        entries.forEach(function (entry) {
          if (entry.isIntersecting) {
            entry.target.classList.add('is-visible');
            observer.unobserve(entry.target);
          }
        });
      },
      { rootMargin: '0px 0px -8% 0px', threshold: 0.08 }
    );

    /* Le contenu déjà présent à l'écran est affiché immédiatement (sans attendre
       le premier passage de l'observateur), afin qu'aucun bloc ne reste masqué. */
    items.forEach(function (el) {
      var rect = el.getBoundingClientRect();
      if (rect.top < window.innerHeight * 0.95 && rect.bottom > 0) {
        el.classList.add('is-visible');
      } else {
        observer.observe(el);
      }
    });

    /* Filet de sécurité : si l'observateur ne se déclenche pas (onglet en
       arrière-plan, erreur de script, etc.), on révèle tout après un délai. */
    window.setTimeout(revealAll, 1500);
  }

  /* 5. Formulaires -------------------------------------------------------- */
  function showStatus(statusEl, type, message) {
    if (!statusEl) return;
    statusEl.className = 'form-status is-visible form-status--' + type;
    statusEl.innerHTML = message;
  }

  function initForms() {
    qsa('form[data-table]').forEach(function (form) {
      var statusEl = form.querySelector('.form-status');
      var submitBtn = form.querySelector('[type="submit"]');

      form.addEventListener('submit', function (event) {
        event.preventDefault();
        if (!form.checkValidity()) {
          form.reportValidity();
          return;
        }

        var payload = {};
        new FormData(form).forEach(function (value, key) {
          if (typeof value === 'string') payload[key] = value.trim();
        });
        payload.statut = payload.statut || 'nouveau';
        payload.cree_le = new Date().toISOString();

        var originalLabel = submitBtn ? submitBtn.innerHTML : '';
        if (submitBtn) {
          submitBtn.disabled = true;
          submitBtn.innerHTML = 'Envoi en cours…';
        }

        fetch(root + 'tables/' + form.getAttribute('data-table'), {
          method: 'POST',
          headers: { 'Content-Type': 'application/json' },
          body: JSON.stringify(payload)
        })
          .then(function (response) {
            if (!response.ok) throw new Error('HTTP ' + response.status);
            return response.json();
          })
          .then(function () {
            form.reset();
            showStatus(
              statusEl,
              'ok',
              '<strong>Merci, votre demande a bien été enregistrée.</strong><br>' +
                'Notre équipe vous recontacte sous 24 à 48 heures ouvrées. ' +
                'Pour une urgence, appelez le <a href="tel:' +
                String(cfg.phone || '').replace(/[^\d+]/g, '') +
                '">' + (cfg.phoneDisplay || '') + '</a>.'
            );
            statusEl.scrollIntoView({ behavior: 'smooth', block: 'center' });
          })
          .catch(function () {
            showStatus(
              statusEl,
              'error',
              "<strong>L'envoi n'a pas abouti.</strong><br>Vérifiez votre connexion internet et réessayez. " +
                "Vous pouvez aussi nous joindre directement par téléphone au " +
                (cfg.phoneDisplay || '') +
                ' ou sur WhatsApp.'
            );
          })
          .then(function () {
            if (submitBtn) {
              submitBtn.disabled = false;
              submitBtn.innerHTML = originalLabel;
            }
          });
      });
    });
  }

  /* Initialisation -------------------------------------------------------- */
  function init() {
    applySiteConfig();
    initNav();
    initHeaderShadow();
    initReveal();
    initForms();
  }

  if (document.readyState === 'loading') {
    document.addEventListener('DOMContentLoaded', init);
  } else {
    init();
  }
})();
